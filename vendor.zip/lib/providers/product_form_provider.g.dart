// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'product_form_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$productFormProviderHash() =>
    r'e95e4631dbe6a08d8be589ee3968869dade12a53';

/// See also [ProductFormProvider].
@ProviderFor(ProductFormProvider)
final productFormProviderProvider =
    AutoDisposeNotifierProvider<ProductFormProvider, ProductsModel>.internal(
  ProductFormProvider.new,
  name: r'productFormProviderProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$productFormProviderHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$ProductFormProvider = AutoDisposeNotifier<ProductsModel>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
