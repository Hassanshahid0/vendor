// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'uuid_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$uuidProviderHash() => r'c961c5abf341a574810e4e64d3fb32a52b55bffa';

/// See also [uuidProvider].
@ProviderFor(uuidProvider)
final uuidProviderProvider = AutoDisposeProvider<String>.internal(
  uuidProvider,
  name: r'uuidProviderProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$uuidProviderHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef UuidProviderRef = AutoDisposeProviderRef<String>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
