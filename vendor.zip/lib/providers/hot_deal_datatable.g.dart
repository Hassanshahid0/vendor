// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'hot_deal_datatable.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$hotDealsStreamHash() => r'db3cedc3488faa6e090e94ca27ba2b80debfb6da';

/// See also [hotDealsStream].
@ProviderFor(hotDealsStream)
final hotDealsStreamProvider =
    AutoDisposeStreamProvider<List<ProductsModel>>.internal(
  hotDealsStream,
  name: r'hotDealsStreamProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$hotDealsStreamHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef HotDealsStreamRef = AutoDisposeStreamProviderRef<List<ProductsModel>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
