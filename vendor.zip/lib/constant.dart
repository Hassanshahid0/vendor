import 'package:flutter/material.dart';

const String googleApiKey = 'AIzaSyAcqpzOvxzn1GHebVAuxZC-25EmCr3n1bs';
Color appColor = Color(0xFFFE7200);
const String email = 'preciousoliver03@gmail.com';
const String serverUrl = 'https://olivette-server.onrender.com';
const String domainUrl = 'https://olivette-single-vendor.web.app';
const String logo = "assets/image/new logo.png";
const String logoLoader = "assets/image/new new splash.png";
const String appName = 'NXT Store';
const String country = 'Pakistan';
String loadingText = 'Loading...';
const String networkText = 'Please check internet connection...';
bool loadingBool = false;
const String projectID = 'ecommerce-multivendor-cd06c';
const playstoreUrl = '';
const appStoreUrl = '';
const String countryCode = 'PK';
const footerDescription =
    'The site is owned and operated by $appName Limited – owners of Marketsquare - a company registered in Nigeria whose registered office is 23 Nzimiro Street, Old GRA, Port Harcourt, Rivers State, Nigeria. Company Registration No. 1181249, TIN No. 17810525 © 2023 olivette-store.web.app All Rights Reserved.';
