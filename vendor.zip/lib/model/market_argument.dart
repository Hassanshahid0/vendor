import 'market.dart';

class MarketArgument {
  final MarketModel marketModel;
  final String vendorID;

  MarketArgument(this.marketModel, this.vendorID);
}
