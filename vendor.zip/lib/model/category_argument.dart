class CategoryArgument {
  final String? category ;
  CategoryArgument(this.category);
}
