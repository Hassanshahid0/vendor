package com.example.vendor_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
